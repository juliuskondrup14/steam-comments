---
name: Bug report
about: Report a bug
title: ''
labels: bug
assignees: ''

---

**Describe the bug**
A clear description of what you did and what happened.

**Full error**
Please post the **complete** error here!

**Additional context**
Please add any other information here if you have some.
