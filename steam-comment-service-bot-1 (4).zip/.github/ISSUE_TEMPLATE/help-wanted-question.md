---
name: Help wanted/Question
about: If you have an error that probably isn't a bug.
title: ''
labels: question
assignees: ''

---

**Error/Element that doesn't work**
Please include the full error you get or if you get none, describe precisely what happened.

**Additional information**
Please add any other information here if you have some.
