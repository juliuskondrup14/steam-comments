---
name: Feature request
about: Suggest an idea or feature
title: ''
labels: enhancement
assignees: ''

---

**Describe the solution you'd like**
A clear description of what should happen.

**Additional context**
Add any other context or screenshots about the feature request here.
